package com.example.hospital;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

public class RecordActivity extends AppCompatActivity {
    private TextView dataTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);
        dataTextView = findViewById(R.id.dataTextView);

        // Retrieve the data passed from MainActivity
        ArrayList<String> namesList = getIntent().getStringArrayListExtra("NAMES_LIST");
        ArrayList<String> doctorList = getIntent().getStringArrayListExtra("DOCTOR_LIST");
        ArrayList<String> diseaseList = getIntent().getStringArrayListExtra("DISEASE_LIST");
        ArrayList<String> medicationsList = getIntent().getStringArrayListExtra("MEDICATIONS_LIST");

        if (namesList != null && diseaseList != null && doctorList != null && medicationsList != null) {
            // Display the data in TextView
            StringBuilder data = new StringBuilder();
            for (int i = 0; i < namesList.size(); i++) {
                data.append("Patience's Name: ").append(namesList.get(i))
                        .append("\nDoctor Name: ").append(doctorList.get(i))
                        .append("\nDisease: ").append(diseaseList.get(i))
                        .append("\nMedication: ").append(medicationsList.get(i))
                        .append("\n\n");
            }
            dataTextView.setText(data.toString());
        }
    }
}