package com.example.hospital;
import java.util.ArrayList;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> namesList = new ArrayList<>();
    private ArrayList<String> doctorList = new ArrayList<>();
    private ArrayList<String> diseaseList = new ArrayList<>();
    private ArrayList<String> medicationsList = new ArrayList<>();
    private EditText nameEditText, doctorEdithText, diseaseEdithText, medicationEdithText;
    private Button submitButton, recordButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameEditText = findViewById(R.id.editTextName);
        doctorEdithText = findViewById(R.id.editTextDoctor);
        diseaseEdithText = findViewById(R.id.editTextDisease);
        medicationEdithText = findViewById(R.id.editTextMedications);
        submitButton = findViewById(R.id.buttonSubmit);
        recordButton = findViewById(R.id.buttonRecord);



        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString();
                String doctor = doctorEdithText.getText().toString();
                String disease = diseaseEdithText.getText().toString();
                String medications = medicationEdithText.getText().toString();

                // Store the data in lists
                namesList.add(name);
                doctorList.add(doctor);
                diseaseList.add(disease);
                medicationsList.add(medications);
                clearInputFields();


            }
        });

        recordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openListActivity();
            }
        });

    }
    private void clearInputFields() {
        nameEditText.setText("");
        doctorEdithText.setText("");
        diseaseEdithText.setText("");
        medicationEdithText.setText("");
    }
    private void openListActivity() {
        Intent intent = new Intent(MainActivity.this,RecordActivity.class);

        // Pass the lists to ListActivity
        intent.putStringArrayListExtra("NAMES_LIST", namesList);
        intent.putStringArrayListExtra("DOCTOR_LIST", doctorList);
        intent.putStringArrayListExtra("DISEASE_LIST", diseaseList);
        intent.putStringArrayListExtra("MEDICATIONS_LIST", medicationsList);
        startActivity(intent);
    }



}
